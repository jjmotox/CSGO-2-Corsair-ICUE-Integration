// CS2 Bomb Lights
// Flashes Corsair iCUE lighting when the bomb is planted in Counter-Strike 2.
//
// Standalone port of CS2-iCUE-BombFlash.ps1. Targets .NET Framework 4.8, which ships with
// Windows 10 and 11, so there is nothing extra to install. On start it:
//   1. writes the Game State Integration .cfg into CS2's cfg folder (finds Steam + CS2 itself),
//   2. finds the iCUE SDK DLL (next to the exe, or inside the iCUESDK_*.zip in Downloads),
//   3. connects to iCUE,
//   4. launches CS2 through Steam if it isn't running yet,
//   5. listens on 127.0.0.1 for CS2's game-state updates and flashes the lights on a plant,
//   6. closes itself, restoring normal lighting, when CS2 exits.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

[assembly: AssemblyTitle("CS2 Bomb Lights")]
[assembly: AssemblyDescription("Flashes Corsair iCUE lighting when the bomb is planted in Counter-Strike 2")]
[assembly: AssemblyProduct("CS2 Bomb Lights")]
[assembly: AssemblyVersion("1.6.0.0")]
[assembly: AssemblyFileVersion("1.6.0.0")]

namespace CS2BombLights
{
    // -----------------------------------------------------------------------------------------
    // Entry point
    // -----------------------------------------------------------------------------------------
    static class Program
    {
        public const string Version = "1.6";
        public const string AuthToken = "icue-bomb-flash-7f3a9c";

        static readonly ManualResetEvent ExitRequested = new ManualResetEvent(false);
        static int _cleanedUp;

        delegate bool ConsoleCtrlHandler(int ctrlType);
        static ConsoleCtrlHandler _ctrlHandler;   // kept in a field so the GC can't collect it

        [DllImport("kernel32.dll")]
        static extern bool SetConsoleCtrlHandler(ConsoleCtrlHandler handler, bool add);

        [DllImport("kernel32.dll")]
        static extern uint GetConsoleProcessList(uint[] processList, uint count);

        static int Main(string[] args)
        {
            try { Console.Title = "CS2 Bomb Lights"; } catch { }

            Options o;
            try { o = Options.Parse(args); }
            catch (ArgumentException ex)
            {
                Log.Write("FAILURE: " + ex.Message, ConsoleColor.Red);
                PrintUsage();
                return Finish(2);
            }

            if (o.Help)
            {
                PrintUsage();
                return Finish(0, true);
            }

            Log.Write("CS2 Bomb Lights " + Version + ". Flash color #" + o.ColorHex +
                      (o.OnlyMine ? ", only your own plants" : ", any plant") +
                      ", blinks synced to the C4 beep (" + o.BombTimer + " s timer" +
                      (o.OffsetGiven ? ", teammate plants assumed " + o.OffsetMs + " ms late" : "") + ").", ConsoleColor.White);

            if (!Environment.Is64BitProcess)
            {
                Log.Write("FAILURE: This needs 64-bit Windows (the iCUE SDK is 64-bit only).", ConsoleColor.Red);
                return Finish(1);
            }

            bool firstInstance;
            using (var mutex = new Mutex(true, "Local\\CS2BombLights", out firstInstance))
            {
                if (!firstInstance)
                {
                    Log.Write("CS2 Bomb Lights is already running in another window.", ConsoleColor.Yellow);
                    return Finish(1);
                }

                InstallCloseHandler();
                try { return Run(o); }
                finally { Cleanup(); }
            }
        }

        static int Run(Options o)
        {
            // --- iCUE SDK -------------------------------------------------------------------
            string sdkSource;
            string dllPath = SdkLocator.Find(out sdkSource);
            if (dllPath == null)
            {
                Log.Write("FAILURE: Could not find the iCUE SDK (iCUESDK.x64_2019.dll).", ConsoleColor.Red);
                Log.Write("Download iCUESDK_4.0.84.zip from https://github.com/CorsairOfficial/cue-sdk/releases", ConsoleColor.Yellow);
                Log.Write("and put the zip (or iCUESDK.x64_2019.dll from its redist\\x64 folder) next to this exe", ConsoleColor.Yellow);
                Log.Write("or in your Downloads folder, then run this again.", ConsoleColor.Yellow);
                return Finish(1);
            }
            Log.Write("iCUE SDK: " + sdkSource, ConsoleColor.DarkGray);

            Icue.R = o.R; Icue.G = o.G; Icue.B = o.B;
            Icue.BombTimer = o.BombTimer;
            try
            {
                string devices = Icue.Connect(dllPath);
                Log.Write("Connected to iCUE. Devices: " + devices, ConsoleColor.Green);
            }
            catch (Exception ex)
            {
                Log.Write("FAILURE: " + ex.Message, ConsoleColor.Red);
                return Finish(1);
            }

            if (o.Test)
            {
                if (o.TestEffect == "all")
                    foreach (string e in Options.TestEffects) { if (e != "all") { RunEffectTest(e, o); Thread.Sleep(800); } }
                else
                    RunEffectTest(o.TestEffect, o);
                Thread.Sleep(300);
                Cleanup();
                Log.Write("Test finished. Your normal lighting should be back.", ConsoleColor.Green);
                return Finish(0, true);
            }

            // --- CS2 game state integration config ---------------------------------------
            bool gameAlreadyRunning = Game.IsRunning();
            string cfgMessage;
            ConfigResult cfg = SteamSetup.InstallConfig(o.Port, out cfgMessage);
            switch (cfg)
            {
                case ConfigResult.Unchanged:
                    Log.Write("CS2 config OK: " + cfgMessage, ConsoleColor.DarkGray);
                    break;
                case ConfigResult.Written:
                    Log.Write("Installed CS2 config: " + cfgMessage, ConsoleColor.Green);
                    if (gameAlreadyRunning)
                        Log.Write("CS2 is already open, so restart it once to load the new config.", ConsoleColor.Yellow);
                    break;
                default:
                    Log.Write("WARNING: " + cfgMessage, ConsoleColor.Yellow);
                    break;
            }

            // --- Listen for CS2 -------------------------------------------------------------
            var bomb = new BombTracker(o.OnlyMine, o.OffsetMs, o.OffsetGiven);
            bomb.Debug = o.Debug;
            if (o.Debug) Log.Write("Debug mode: showing what CS2 sends about you whenever it changes.", ConsoleColor.Magenta);
            var server = new GsiServer(bomb.OnUpdate);
            try { server.Start(o.Port); }
            catch (SocketException ex)
            {
                Log.Write("FAILURE: Could not listen on port " + o.Port + " (" + ex.Message + "). " +
                          "Another program may be using it; run with --port 3001.", ConsoleColor.Red);
                return Finish(1);
            }
            Log.Write("Listening for CS2 on 127.0.0.1:" + o.Port + ".", ConsoleColor.Green);

            try
            {
                bool seenGame = gameAlreadyRunning;
                if (seenGame)
                    Log.Write("CS2 is running. Close this window to stop.", ConsoleColor.Green);
                else if (o.NoLaunch)
                    Log.Write("Waiting for CS2 to start...", ConsoleColor.Gray);
                else
                    Game.Launch();

                while (!ExitRequested.WaitOne(2000))
                {
                    bool running = Game.IsRunning();
                    if (running && !seenGame)
                    {
                        seenGame = true;
                        Log.Write("CS2 is running. Close this window to stop.", ConsoleColor.Green);
                    }
                    else if (!running && seenGame && !o.Stay)
                    {
                        Log.Write("CS2 closed.", ConsoleColor.Gray);
                        break;
                    }
                }
            }
            finally
            {
                server.Stop();
                bomb.Stop();
                Cleanup();
                Log.Write("Stopped. Lighting handed back to iCUE.", ConsoleColor.Yellow);
            }
            return 0;
        }

        // Plays one effect the way it looks in a match, without CS2.
        static void RunEffectTest(string effect, Options o)
        {
            switch (effect)
            {
                case "bomb":
                    Log.Write("Test: bomb countdown, 6 seconds of the beep-synced blinking...", ConsoleColor.Cyan);
                    Icue.StartFlash(o.OffsetGiven ? o.OffsetMs / 1000.0 : 0); Thread.Sleep(6000); Icue.StopFlash();
                    break;
                case "hit":
                    Log.Write("Test: hit flash. A small hit, a medium hit, then a big hit...", ConsoleColor.Cyan);
                    Icue.Hit(15); Thread.Sleep(1000); Icue.Hit(40); Thread.Sleep(1000); Icue.Hit(80); Thread.Sleep(1200);
                    break;
                case "death":
                    Log.Write("Test: death. Red jolt, grey while dead for 3 seconds, then respawn...", ConsoleColor.Cyan);
                    Icue.SetDead(true); Thread.Sleep(3000); Icue.SetDead(false); Thread.Sleep(500);
                    break;
                case "flash":
                    Log.Write("Test: flashbang. Full white for a second, then fading out like your screen clears...", ConsoleColor.Cyan);
                    Icue.SetFlashed(255); Thread.Sleep(1000);
                    for (int v = 255; v >= 0; v -= 5) { Icue.SetFlashed(v); Thread.Sleep(50); }
                    Icue.SetFlashed(0); Thread.Sleep(300);
                    break;
                case "smoke":
                    Log.Write("Test: smoke. Walking into a smoke, standing in it, walking out...", ConsoleColor.Cyan);
                    for (int v = 0; v <= 255; v += 25) { Icue.SetSmoked(v); Thread.Sleep(50); }
                    Icue.SetSmoked(255); Thread.Sleep(2000);
                    for (int v = 255; v >= 0; v -= 13) { Icue.SetSmoked(v); Thread.Sleep(50); }
                    Icue.SetSmoked(0); Thread.Sleep(300);
                    break;
                case "headshot":
                    Log.Write("Test: headshot burst, twice...", ConsoleColor.Cyan);
                    Icue.Headshot(); Thread.Sleep(1200); Icue.Headshot(); Thread.Sleep(1000);
                    break;
                case "kill":
                    Log.Write("Test: kill (not a headshot), twice...", ConsoleColor.Cyan);
                    Icue.Kill(); Thread.Sleep(1200); Icue.Kill(); Thread.Sleep(1000);
                    break;
                case "hitmarker":
                    Log.Write("Test: hit markers. A tap, a spray of body shots, then a big hit...", ConsoleColor.Cyan);
                    Icue.HitMarker(20); Thread.Sleep(700);
                    for (int i = 0; i < 4; i++) { Icue.HitMarker(25); Thread.Sleep(110); }
                    Thread.Sleep(600); Icue.HitMarker(100); Thread.Sleep(700);
                    break;
                case "win":
                    Log.Write("Test: round won. As CT (blue), then as T (orange)...", ConsoleColor.Cyan);
                    Icue.RoundWon("CT"); Thread.Sleep(2200); Icue.RoundWon("T"); Thread.Sleep(2200);
                    break;
                case "defuse":
                    Log.Write("Test: bomb defused. 3 seconds of bomb countdown, then the defuse burst...", ConsoleColor.Cyan);
                    Icue.StartFlash(0); Thread.Sleep(3000); Icue.StopFlash(); Icue.Defused(); Thread.Sleep(1800);
                    break;
            }
        }

        // Restores normal lighting. Safe to call more than once and from any thread.
        static void Cleanup()
        {
            if (Interlocked.Exchange(ref _cleanedUp, 1) != 0) return;
            try { Icue.Shutdown(); } catch { }
        }

        static void InstallCloseHandler()
        {
            // Ctrl+C / Ctrl+Break: stop the main loop and clean up normally.
            Console.CancelKeyPress += (s, e) => { e.Cancel = true; ExitRequested.Set(); };

            // Closing the window, logging off, shutting down: Windows only gives a few seconds,
            // so restore the lighting right here.
            try
            {
                _ctrlHandler = type =>
                {
                    if (type == 2 || type == 5 || type == 6) { Cleanup(); return true; }
                    return false;   // let Ctrl+C fall through to CancelKeyPress
                };
                SetConsoleCtrlHandler(_ctrlHandler, true);
            }
            catch { /* not on Windows */ }
        }

        // When the exe was double-clicked, the console closes the moment we exit, so pause on
        // errors (and after --test / --help) to give a chance to read the output.
        static int Finish(int code, bool pauseEvenOnSuccess = false)
        {
            if ((code != 0 || pauseEvenOnSuccess) && OwnsConsole())
            {
                Console.WriteLine();
                Console.Write("Press any key to close...");
                try { Console.ReadKey(true); } catch { }
            }
            return code;
        }

        static bool OwnsConsole()
        {
            try
            {
                if (Console.IsInputRedirected) return false;
                return GetConsoleProcessList(new uint[4], 4) == 1;
            }
            catch { return false; }
        }

        static void PrintUsage()
        {
            Console.WriteLine();
            Console.WriteLine("Usage: CS2BombLights.exe [options]");
            Console.WriteLine();
            Console.WriteLine("  (no options)      Set everything up, start CS2 through Steam, flash on every plant,");
            Console.WriteLine("                    and close automatically when CS2 closes.");
            Console.WriteLine("  --test [effect]   Play an effect without CS2, then exit. Effects: bomb (default),");
            Console.WriteLine("                    hit, death, flash, smoke, headshot, kill, hitmarker, win, defuse, all.");
            Console.WriteLine("  --only-mine       Only flash when YOU plant, not when a teammate does.");
            Console.WriteLine("  --color FF6A00    Flash color as a hex code (default FF0000, red).");
            Console.WriteLine("  --no-launch       Don't start CS2; just wait for it.");
            Console.WriteLine("  --stay            Keep running after CS2 closes.");
            Console.WriteLine("  --port 3001       Local port for CS2 updates (default 3000). The CS2 config is");
            Console.WriteLine("                    rewritten to match automatically.");
            Console.WriteLine("  --offset 250      For teammates' plants: how late CS2 reports them, in ms. By default");
            Console.WriteLine("                    it is measured from your own plants (250 until then). Your own");
            Console.WriteLine("                    plants are caught instantly and need no offset.");
            Console.WriteLine("  --bomb-timer 40   Bomb timer in seconds, for servers that change mp_c4timer.");
            Console.WriteLine("  --no-hit, --no-death, --no-flash, --no-smoke, --no-headshot, --no-kill,");
            Console.WriteLine("  --no-hitmarker, --no-win, --no-defuse");
            Console.WriteLine("                    Turn off one of the extra effects.");
            Console.WriteLine("  --debug           Show what CS2 sends about you (health, kills, headshots...).");
            Console.WriteLine();
        }
    }

    // -----------------------------------------------------------------------------------------
    // Command-line options. Accepts --only-mine, -OnlyMyPlants, /test, --color=FF0000, etc.
    // -----------------------------------------------------------------------------------------
    sealed class Options
    {
        public int Port = 3000;
        public byte R = 255, G = 0, B = 0;
        public string ColorHex = "FF0000";
        public int BombTimer = 40;
        public int OffsetMs = 250;   // how late CS2 reports plants we couldn't see happen ourselves
        public bool OffsetGiven;
        public bool OnlyMine, Test, NoLaunch, Stay, Help, Debug;
        public string TestEffect = "bomb";
        public static readonly string[] TestEffects = { "bomb", "hit", "death", "flash", "smoke", "headshot", "kill", "hitmarker", "win", "defuse", "all" };

        public static Options Parse(string[] args)
        {
            var o = new Options();
            for (int i = 0; i < args.Length; i++)
            {
                string raw = args[i];
                string name = raw.TrimStart('-', '/');
                string inlineValue = null;
                int sep = name.IndexOfAny(new[] { '=', ':' });
                if (sep >= 0) { inlineValue = name.Substring(sep + 1); name = name.Substring(0, sep); }
                name = name.Replace("-", "").Replace("_", "").ToLowerInvariant();

                switch (name)
                {
                    case "test":
                        o.Test = true;
                        string effect = inlineValue;
                        if (effect == null && i + 1 < args.Length && !args[i + 1].StartsWith("-") && !args[i + 1].StartsWith("/"))
                            effect = args[++i];
                        if (effect != null)
                        {
                            effect = effect.ToLowerInvariant();
                            if (effect == "flashbang") effect = "flash";
                            if (effect == "marker" || effect == "hitmarkers") effect = "hitmarker";
                            if (effect == "won" || effect == "roundwon") effect = "win";
                            if (Array.IndexOf(TestEffects, effect) < 0)
                                throw new ArgumentException("Unknown test effect '" + effect + "'. Use one of: " + string.Join(", ", TestEffects) + ".");
                            o.TestEffect = effect;
                        }
                        break;
                    case "onlymine": case "onlymyplants": case "mine": o.OnlyMine = true; break;
                    case "nolaunch": o.NoLaunch = true; break;
                    case "stay": case "keepopen": o.Stay = true; break;
                    case "debug": case "verbose": o.Debug = true; break;
                    case "help": case "h": case "?": o.Help = true; break;
                    case "color": case "colour":
                        o.SetColor(inlineValue ?? NextValue(args, ref i, raw));
                        break;
                    case "port":
                        string p = inlineValue ?? NextValue(args, ref i, raw);
                        int port;
                        if (!int.TryParse(p, NumberStyles.None, CultureInfo.InvariantCulture, out port) || port < 1024 || port > 65535)
                            throw new ArgumentException("Port must be a number from 1024 to 65535 (got '" + p + "').");
                        o.Port = port;
                        break;
                    case "bombtimer": case "c4timer":
                        o.BombTimer = IntValue(inlineValue ?? NextValue(args, ref i, raw), 10, 120, "Bomb timer must be 10 to 120 seconds");
                        break;
                    case "offset":
                        o.OffsetMs = IntValue(inlineValue ?? NextValue(args, ref i, raw), -2000, 2000, "Offset must be -2000 to 2000 milliseconds");
                        o.OffsetGiven = true;
                        break;
                    default:
                        if (name.StartsWith("no") && Array.IndexOf(Fx.All, name.Substring(2)) >= 0)
                        {
                            if (!Fx.Off.Contains(name.Substring(2))) Fx.Off.Add(name.Substring(2));
                            break;
                        }
                        throw new ArgumentException("Unknown option '" + raw + "'.");
                }
            }
            return o;
        }

        static int IntValue(string s, int min, int max, string error)
        {
            int v;
            if (!int.TryParse(s, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out v) || v < min || v > max)
                throw new ArgumentException(error + " (got '" + s + "').");
            return v;
        }

        static string NextValue(string[] args, ref int i, string option)
        {
            if (i + 1 >= args.Length) throw new ArgumentException("Option '" + option + "' needs a value.");
            return args[++i];
        }

        void SetColor(string value)
        {
            string hex = (value ?? "").Trim().TrimStart('#');
            if (!Regex.IsMatch(hex, "^[0-9A-Fa-f]{6}$"))
                throw new ArgumentException("Color must be a 6-digit hex code like FF0000 (got '" + value + "').");
            R = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            G = byte.Parse(hex.Substring(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            B = byte.Parse(hex.Substring(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            ColorHex = hex.ToUpperInvariant();
        }
    }

    static class Log
    {
        static readonly object Lock = new object();

        public static void Write(string message, ConsoleColor color = ConsoleColor.Gray)
        {
            lock (Lock)
            {
                ConsoleColor old = Console.ForegroundColor;
                try
                {
                    Console.ForegroundColor = color;
                    Console.WriteLine("[" + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "] " + message);
                }
                finally { Console.ForegroundColor = old; }
            }
        }
    }

    // Which effects are switched on (all by default; --no-hit etc. turns one off).
    static class Fx
    {
        public static readonly string[] All = { "hit", "death", "flash", "smoke", "headshot", "kill", "hitmarker", "win", "defuse" };
        public static readonly List<string> Off = new List<string>();
        public static bool On(string name) { return !Off.Contains(name); }
    }

    // -----------------------------------------------------------------------------------------
    // Bomb state tracking
    //
    // For players (not spectators), CS2 deliberately reports "bomb planted" after a short random
    // delay so it can't be used as an exact bomb timer. Your own C4 inventory isn't delayed,
    // though, so when YOU plant we react the moment the C4 leaves your hands, and treat CS2's
    // later "planted" report as confirmation. Plants we didn't see (teammates) can only be
    // caught through the delayed report; for those, the blink schedule is shifted by the delay
    // measured on your own plants (or --offset).
    // -----------------------------------------------------------------------------------------
    sealed class BombTracker
    {
        const double MinC4InHandSeconds = 2.5;    // planting takes 3 s with the C4 out
        const double ConfirmWindowSeconds = 1.5;  // no "planted" report by then: it was a drop, not a plant
        const double ResumeWindowSeconds = 10;    // a later report still resumes, in sync with the real plant

        static readonly Stopwatch Clock = Stopwatch.StartNew();
        static double Now { get { return Clock.Elapsed.TotalSeconds; } }

        readonly bool _onlyMine;
        readonly double _defaultDelay;
        readonly bool _delayFixed;
        readonly object _lock = new object();
        readonly List<double> _measuredDelays = new List<double>();
        readonly Timer _watchdog;

        string _lastBomb;
        bool _iCarryC4;
        double _c4LostAt = double.NegativeInfinity;
        double _c4InHandSince = double.NaN;          // NaN = not holding it
        double _predictedPlantAt = double.NaN;       // NaN = no recent plant seen
        bool _awaitingConfirmation;

        // For the other effects
        int _prevHealth = -1;          // -1 = unknown (not you, or no data yet)
        int _prevHeadshots = -1;
        int _prevKills = -1;
        int _prevDamage = -1;
        string _myTeam;
        string _lastPhase;

        public BombTracker(bool onlyMine, int delayMs, bool delayFixed)
        {
            _onlyMine = onlyMine;
            _defaultDelay = delayMs / 1000.0;
            _delayFixed = delayFixed;
            _watchdog = new Timer(Watchdog, null, 100, 100);
        }

        // Called on the listener thread, one update at a time, in the order CS2 sent them.
        public void OnUpdate(string body)
        {
            Dictionary<string, object> gs;
            try { gs = Json.Parse(body) as Dictionary<string, object>; }
            catch (Exception) { return; }
            if (gs == null) return;
            if (Json.Str(Json.Obj(gs, "auth"), "token") != Program.AuthToken) return;   // not our config

            lock (_lock)
            {
                Diagnose(gs);
                Handle(gs, Now);
            }
        }

        void Handle(Dictionary<string, object> gs, double now)
        {
            var player = Json.Obj(gs, "player");
            var provider = Json.Obj(gs, "provider");
            string bomb = Json.Str(Json.Obj(gs, "round"), "bomb");

            bool hadC4Before = _iCarryC4;
            string playerId = Json.Str(player, "steamid");
            bool isMe = playerId != null && playerId == Json.Str(provider, "steamid");
            if (isMe)
            {
                bool carrying = false, inHand = false;
                var weapons = Json.Obj(player, "weapons");
                if (weapons != null)
                {
                    foreach (var w in weapons.Values)
                    {
                        var wd = w as Dictionary<string, object>;
                        if (Json.Str(wd, "name") != "weapon_c4") continue;
                        carrying = true;
                        inHand = Json.Str(wd, "state") == "active";
                        break;
                    }
                }
                double health = Json.Num(Json.Obj(player, "state"), "health", -1);

                if (_iCarryC4 && !carrying) _c4LostAt = now;

                // Your plant: the C4 was in your hands long enough to plant it, and now it's gone
                // while you're still alive (dying or dropping it mid-plant doesn't count).
                if (!double.IsNaN(_c4InHandSince) && !carrying && health != 0 &&
                    now - _c4InHandSince >= MinC4InHandSeconds && bomb != "planted" && !Icue.IsFlashing)
                {
                    _predictedPlantAt = now;
                    _awaitingConfirmation = true;
                    Log.Write("You planted the bomb! Flashing.", ConsoleColor.Red);
                    Icue.StartFlash(0);
                }

                _iCarryC4 = carrying;
                if (!inHand) _c4InHandSince = double.NaN;
                else if (double.IsNaN(_c4InHandSince)) _c4InHandSince = now;
            }
            else
            {
                _iCarryC4 = false;                 // spectating someone else means you're dead
                _c4InHandSince = double.NaN;
            }

            UpdateEffects(gs, player, isMe);

            if (bomb == "planted" && _lastBomb != "planted")
            {
                if (!double.IsNaN(_predictedPlantAt) && now - _predictedPlantAt < ResumeWindowSeconds)
                {
                    // CS2 confirming the plant we already reacted to. The gap is its built-in delay.
                    double delay = now - _predictedPlantAt;
                    _awaitingConfirmation = false;
                    if (delay < ConfirmWindowSeconds)   // a very late report might not be this plant; don't learn from it
                    {
                        _measuredDelays.Add(delay);
                        if (_measuredDelays.Count > 20) _measuredDelays.RemoveAt(0);
                    }
                    Log.Write("CS2 reported your plant " + Ms(delay) + " after it happened.", ConsoleColor.DarkGray);
                    if (!Icue.IsFlashing)
                    {
                        Log.Write("Flashing.", ConsoleColor.Red);
                        Icue.StartFlash(delay);
                    }
                }
                else
                {
                    bool mine = hadC4Before || now - _c4LostAt < 2;
                    if (_onlyMine && !mine)
                    {
                        Log.Write("Bomb planted by a teammate (ignored because of --only-mine).", ConsoleColor.DarkGray);
                    }
                    else
                    {
                        double delay = DelayEstimate();
                        Log.Write("Bomb planted" + (mine ? " by you" : "") + "! Flashing (assuming CS2 reported it " +
                                  Ms(delay) + " late).", ConsoleColor.Red);
                        Icue.StartFlash(delay);
                    }
                }
                _predictedPlantAt = double.NaN;
            }
            else if (_lastBomb == "planted" && bomb != "planted")
            {
                if (Icue.IsFlashing)
                    Log.Write("Bomb " + (bomb ?? "cleared (new round)") + ". Lighting restored.", ConsoleColor.Cyan);
                Icue.StopFlash();
                if (bomb == "defused" && Fx.On("defuse")) Icue.Defused();
            }

            _lastBomb = bomb;
        }

        // Cancels a flash we started on our own if CS2 never confirms the plant (the C4 was dropped).
        void Watchdog(object state)
        {
            lock (_lock)
            {
                if (!_awaitingConfirmation || Now - _predictedPlantAt < ConfirmWindowSeconds) return;
                _awaitingConfirmation = false;    // keep _predictedPlantAt: a late report still resumes in sync
                Icue.StopFlash();
                Log.Write("CS2 didn't report a plant, so the C4 was probably dropped. Lighting restored.", ConsoleColor.DarkGray);
            }
        }

        public void Stop() { _watchdog.Dispose(); }

        public bool Debug;
        string _lastSummary;
        bool _warnedNoState;
        int _updatesWithoutState;

        // Explains in the window when CS2 isn't sending what the effects need, and in --debug mode
        // prints the relevant values every time they change.
        void Diagnose(Dictionary<string, object> gs)
        {
            var player = Json.Obj(gs, "player");
            var provider = Json.Obj(gs, "provider");
            var ps = Json.Obj(player, "state");
            string pid = Json.Str(player, "steamid");
            bool isMe = pid != null && pid == Json.Str(provider, "steamid");

            if (player != null && Json.Str(player, "activity") == "playing" && ps == null)
            {
                if (++_updatesWithoutState >= 3 && !_warnedNoState)
                {
                    _warnedNoState = true;
                    Log.Write("CS2 isn't sending your health/kill data, so hit, death, flashbang, smoke and headshot " +
                              "effects can't work. Close CS2 and start it again through this program so it loads the updated config.",
                              ConsoleColor.Yellow);
                }
            }
            else if (ps != null) _updatesWithoutState = 0;

            if (!Debug) return;
            var round = Json.Obj(gs, "round");
            string summary = "you=" + (player == null ? "none" : isMe ? "yes" : "spectating") +
                " activity=" + (Json.Str(player, "activity") ?? "-") +
                " team=" + (Json.Str(player, "team") ?? "-") +
                (ps == null ? " state=MISSING" :
                    " hp=" + Json.Num(ps, "health", -1) + " kills=" + Json.Num(ps, "round_kills", -1) +
                    " hs=" + Json.Num(ps, "round_killhs", -1) + " dmg=" + Json.Num(ps, "round_totaldmg", -1) +
                    " flashed=" + Json.Num(ps, "flashed", -1) + " smoked=" + Json.Num(ps, "smoked", -1)) +
                " phase=" + (Json.Str(round, "phase") ?? "-") + " bomb=" + (Json.Str(round, "bomb") ?? "-") +
                " win=" + (Json.Str(round, "win_team") ?? "-");
            if (summary != _lastSummary) { _lastSummary = summary; Log.Write("CS2: " + summary, ConsoleColor.Magenta); }
        }

        // Hit flash, death, flashbang, smoke, headshot and round-won effects.
        void UpdateEffects(Dictionary<string, object> gs, Dictionary<string, object> player, bool isMe)
        {
            var round = Json.Obj(gs, "round");
            string phase = Json.Str(round, "phase");
            var ps = Json.Obj(player, "state");
            string activity = Json.Str(player, "activity");

            if (activity == "menu" || player == null)
            {
                // In the main menu or between maps: drop anything tied to being in a match.
                Icue.ClearPlayerState();
                _prevHealth = -1; _prevHeadshots = -1; _prevKills = -1; _prevDamage = -1;
            }
            else if (isMe && ps != null)
            {
                int health = (int)Json.Num(ps, "health", -1);
                int headshots = (int)Json.Num(ps, "round_killhs", 0);
                int kills = (int)Json.Num(ps, "round_kills", 0);
                int damage = (int)Json.Num(ps, "round_totaldmg", -1);   // -1: CS2 didn't send it
                string team = Json.Str(player, "team");
                if (team != null) _myTeam = team;

                if (Fx.On("hit") && _prevHealth > 0 && health >= 0 && health < _prevHealth && health > 0)
                    Icue.Hit(_prevHealth - health);

                if (health == 0 && _prevHealth != 0)
                {
                    if (Fx.On("death")) { Icue.SetDead(true); Log.Write("You died.", ConsoleColor.DarkGray); }
                }
                else if (health > 0) Icue.SetDead(false);

                bool newHeadshot = _prevHeadshots >= 0 && headshots > _prevHeadshots;
                bool newKill = _prevKills >= 0 && kills > _prevKills;
                if (newHeadshot && Fx.On("headshot"))
                {
                    Icue.Headshot();
                    Log.Write("Headshot!", ConsoleColor.Yellow);
                }
                else if (newKill && !newHeadshot && Fx.On("kill"))
                {
                    Icue.Kill();
                    Log.Write("Kill!", ConsoleColor.White);
                }
                else if (Fx.On("hitmarker") && damage >= 0 && _prevDamage >= 0 && damage > _prevDamage)
                {
                    Icue.HitMarker(damage - _prevDamage);   // damage without a kill: hit marker
                }

                Icue.SetFlashed(Fx.On("flash") && health != 0 ? (int)Json.Num(ps, "flashed", 0) : 0);
                Icue.SetSmoked(Fx.On("smoke") && health != 0 ? (int)Json.Num(ps, "smoked", 0) : 0);

                _prevHealth = health;
                _prevHeadshots = headshots;
                _prevKills = kills;
                _prevDamage = damage;
            }
            else if (!isMe && player != null)
            {
                // Spectating someone else: you're dead, and their flash/smoke isn't yours.
                if (_prevHealth > 0 && phase == "live" && Fx.On("death"))
                {
                    Icue.SetDead(true);
                    Log.Write("You died.", ConsoleColor.DarkGray);
                }
                Icue.SetFlashed(0);
                Icue.SetSmoked(0);
                _prevHealth = 0;
            }

            if (phase == "freezetime" && _lastPhase != "freezetime") Icue.SetDead(false);   // new round

            if (phase == "over" && _lastPhase != "over")
            {
                string winner = Json.Str(round, "win_team");
                if (winner != null && winner == _myTeam && Fx.On("win"))
                {
                    Icue.RoundWon(winner);
                    Log.Write("Round won!", winner == "CT" ? ConsoleColor.Blue : ConsoleColor.DarkYellow);
                }
            }
            _lastPhase = phase;
        }

        double DelayEstimate()
        {
            if (_delayFixed || _measuredDelays.Count == 0) return _defaultDelay;
            double sum = 0;
            foreach (double d in _measuredDelays) sum += d;
            return sum / _measuredDelays.Count;
        }

        static string Ms(double seconds) { return Math.Round(seconds * 1000).ToString(CultureInfo.InvariantCulture) + " ms"; }
    }

    // -----------------------------------------------------------------------------------------
    // Minimal HTTP listener for CS2 Game State Integration posts. Uses a plain TCP socket bound
    // to 127.0.0.1, so it needs no admin rights or URL reservation and is never reachable from
    // the network.
    // -----------------------------------------------------------------------------------------
    sealed class GsiServer
    {
        const int MaxHeaderBytes = 64 * 1024;
        const int MaxBodyBytes = 4 * 1024 * 1024;
        static readonly byte[] HeaderEnd = { 13, 10, 13, 10 };

        readonly Action<string> _onBody;
        TcpListener _listener;
        volatile bool _stopping;

        public GsiServer(Action<string> onBody) { _onBody = onBody; }

        public void Start(int port)
        {
            // No SO_EXCLUSIVEADDRUSE: with it, Windows keeps the port blocked for up to 4 minutes
            // (TIME_WAIT) after we exit, so restarting the app right after closing CS2 would fail.
            _listener = new TcpListener(IPAddress.Loopback, port);
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            _listener.Start();
            var t = new Thread(AcceptLoop) { IsBackground = true, Name = "GSI listener" };
            t.Start();
        }

        public void Stop()
        {
            _stopping = true;
            try { if (_listener != null) _listener.Stop(); } catch { }
        }

        void AcceptLoop()
        {
            while (!_stopping)
            {
                TcpClient client;
                try { client = _listener.AcceptTcpClient(); }
                catch (Exception) { if (_stopping) return; Thread.Sleep(100); continue; }

                // One connection at a time keeps updates in order. CS2 posts a few times a second
                // at most, and everything here is local, so this never backs up.
                string body = null;
                try { body = ReadRequest(client); }
                catch (Exception) { }
                finally { try { client.Close(); } catch { } }

                if (body != null)
                {
                    try { _onBody(body); }
                    catch (Exception ex) { Log.Write("Error handling a CS2 update: " + ex.Message, ConsoleColor.DarkYellow); }
                }
            }
        }

        // Reads one HTTP request, replies 200, and returns the body (null for non-POST).
        static string ReadRequest(TcpClient client)
        {
            client.ReceiveTimeout = 5000;
            client.SendTimeout = 5000;
            NetworkStream stream = client.GetStream();

            var buffer = new MemoryStream();
            var chunk = new byte[8192];
            int headerEnd = -1;
            while (headerEnd < 0)
            {
                int n = stream.Read(chunk, 0, chunk.Length);
                if (n <= 0) return null;
                buffer.Write(chunk, 0, n);
                if (buffer.Length > MaxHeaderBytes) { Reply(stream, "431 Request Header Fields Too Large"); return null; }
                headerEnd = IndexOf(buffer.GetBuffer(), (int)buffer.Length, HeaderEnd);
            }

            byte[] raw = buffer.GetBuffer();
            string head = Encoding.ASCII.GetString(raw, 0, headerEnd);
            string[] lines = head.Split(new[] { "\r\n" }, StringSplitOptions.None);
            bool isPost = lines.Length > 0 && lines[0].StartsWith("POST ", StringComparison.OrdinalIgnoreCase);

            int contentLength = 0;
            for (int i = 1; i < lines.Length; i++)
            {
                int colon = lines[i].IndexOf(':');
                if (colon <= 0) continue;
                if (string.Equals(lines[i].Substring(0, colon).Trim(), "Content-Length", StringComparison.OrdinalIgnoreCase))
                {
                    if (!int.TryParse(lines[i].Substring(colon + 1).Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out contentLength))
                    { Reply(stream, "400 Bad Request"); return null; }
                }
            }
            if (contentLength > MaxBodyBytes) { Reply(stream, "413 Payload Too Large"); return null; }

            var body = new byte[contentLength];
            int bodyStart = headerEnd + HeaderEnd.Length;
            int got = Math.Min((int)buffer.Length - bodyStart, contentLength);

            // Some HTTP clients send only the headers with "Expect: 100-continue" and wait (often a
            // second or more) for a go-ahead before sending the body. Give it right away.
            if (got < contentLength && head.IndexOf("100-continue", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                byte[] go = Encoding.ASCII.GetBytes("HTTP/1.1 100 Continue\r\n\r\n");
                stream.Write(go, 0, go.Length);
                stream.Flush();
            }
            if (got > 0) Buffer.BlockCopy(raw, bodyStart, body, 0, got);
            while (got < contentLength)
            {
                int n = stream.Read(body, got, contentLength - got);
                if (n <= 0) return null;
                got += n;
            }

            Reply(stream, "200 OK");
            return isPost ? Encoding.UTF8.GetString(body) : null;
        }

        static void Reply(NetworkStream stream, string status)
        {
            byte[] r = Encoding.ASCII.GetBytes("HTTP/1.1 " + status + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
            stream.Write(r, 0, r.Length);
            stream.Flush();
        }

        static int IndexOf(byte[] data, int length, byte[] pattern)
        {
            for (int i = 0; i <= length - pattern.Length; i++)
            {
                int j = 0;
                while (j < pattern.Length && data[i + j] == pattern[j]) j++;
                if (j == pattern.Length) return i;
            }
            return -1;
        }
    }

    // -----------------------------------------------------------------------------------------
    // Corsair iCUE SDK v4 wrapper. Lighting runs on its own timer thread so the flashing stays
    // smooth no matter when CS2 sends updates.
    // -----------------------------------------------------------------------------------------
    static class Icue
    {
        public const string DllName = "iCUESDK.x64_2019.dll";
        const int CSS_Connected = 6;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        struct CorsairDeviceInfo
        {
            public int type;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string id;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string serial;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string model;
            public int ledCount;
            public int channelCount;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct CorsairLedPosition { public uint id; public double cx; public double cy; }

        [StructLayout(LayoutKind.Sequential)]
        struct CorsairDeviceFilter { public int deviceTypeMask; }

        [StructLayout(LayoutKind.Sequential)]
        struct CorsairLedColor { public uint id; public byte r; public byte g; public byte b; public byte a; }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        delegate void SessionStateChangedHandler(IntPtr context, IntPtr eventData);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern IntPtr LoadLibrary(string path);

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        static extern int CorsairConnect(SessionStateChangedHandler onStateChanged, IntPtr context);

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        static extern int CorsairDisconnect();

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        static extern int CorsairGetDevices(ref CorsairDeviceFilter filter, int sizeMax, [In, Out] CorsairDeviceInfo[] devices, out int size);

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        static extern int CorsairGetLedPositions(string deviceId, int sizeMax, [In, Out] CorsairLedPosition[] ledPositions, out int size);

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        static extern int CorsairSetLedColors(string deviceId, int size, [In] CorsairLedColor[] ledColors);

        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        static extern int CorsairSetLayerPriority(uint priority);

        sealed class DeviceLeds
        {
            public string Id;
            public CorsairLedColor[] Colors;
            public double[] X, Y;          // LED positions scaled to 0..1 across the device
            public uint[] LastSent;        // last frame sent, packed RGBA, to skip unchanged frames
        }

        struct Rgba { public double R, G, B, A; public Rgba(double r, double g, double b, double a) { R = r; G = g; B = b; A = a; } }

        static SessionStateChangedHandler _handler;   // kept in a field so the GC can't collect it
        static volatile int _state;
        static readonly List<DeviceLeds> _devices = new List<DeviceLeds>();
        static readonly object _lock = new object();
        static readonly Stopwatch _now = Stopwatch.StartNew();   // the renderer's clock
        static Timer _timer;
        static bool _running, _connected, _fineTimer, _layerOnTop;
        static double _lastSend = -1;

        // --- Bomb countdown -------------------------------------------------------------------
        static bool _flashing, _lit;
        static readonly Stopwatch _clock = new Stopwatch();   // time since the plant was reported
        static double _nextBeep;                              // seconds after the plant
        static double _litUntil;
        static double _startOffset;                           // seconds since the plant when flashing started

        public static byte R = 255, G = 0, B = 0;
        public static double BombTimer = 40;     // seconds; CS2's default mp_c4timer

        // --- Other effects --------------------------------------------------------------------
        static double _hitAt = -99, _hitStrength;
        static bool _dead; static double _deathAt = -99;
        static double _flashed, _smoked;           // 0..1, straight from CS2
        static double _headshotAt = -99;
        static double _winAt = -99; static Rgba _winColor;
        static double _defuseAt = -99;
        static double _markerAt = -99, _markerStrength;
        static double _killAt = -99;

        const double HitSeconds = 0.45, HeadshotSeconds = 0.6, WinSeconds = 1.8, DefuseSeconds = 1.4;
        const double MarkerSeconds = 0.18, KillSeconds = 0.55;

        [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
        [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);

        // CS:GO/CS2 C4 beep spacing (from Valve's leaked game code):
        //   time between beeps = max(0.1 + 0.9 * timeLeft / bombTimer, 0.15)
        // Starts at 1 beep per second and ends at about 6-7 per second.
        public static double BeepInterval(double secondsSincePlant)
        {
            double timeLeft = BombTimer - secondsSincePlant;
            return Math.Max(0.1 + 0.9 * timeLeft / BombTimer, 0.15);
        }

        // How long each flash stays lit: half the gap to the next beep, at most 0.2 s, so it reads
        // as a short blink on every beep.
        static double PulseLength(double interval) { return Math.Min(0.2, interval * 0.5); }

        public static bool IsFlashing { get { lock (_lock) { return _flashing; } } }

        static void OnStateChanged(IntPtr context, IntPtr eventData)
        {
            if (eventData != IntPtr.Zero) _state = Marshal.ReadInt32(eventData);
        }

        public static string Connect(string dllPath)
        {
            if (Environment.OSVersion.Platform == PlatformID.Win32NT && LoadLibrary(dllPath) == IntPtr.Zero)
            {
                int win32 = Marshal.GetLastWin32Error();
                string hint = win32 == 126
                    ? " Install the Microsoft Visual C++ 2015-2022 x64 runtime (aka.ms/vs/17/release/vc_redist.x64.exe) and try again."
                    : " Make sure it is the x64 DLL from the iCUE SDK.";
                throw new Exception("Could not load " + dllPath + " (Win32 error " + win32 + ")." + hint);
            }

            _handler = OnStateChanged;
            int err = CorsairConnect(_handler, IntPtr.Zero);
            if (err != 0) throw new Exception("CorsairConnect failed with error code " + err + ".");
            _connected = true;

            DateTime deadline = DateTime.UtcNow.AddSeconds(10);
            while (_state != CSS_Connected && DateTime.UtcNow < deadline) Thread.Sleep(100);
            if (_state != CSS_Connected)
                throw new Exception("Could not connect to iCUE (session state " + _state +
                    "). Make sure iCUE is running and the iCUE SDK setting is turned on (iCUE Settings > General > Enable SDK).");

            var filter = new CorsairDeviceFilter { deviceTypeMask = -1 };   // CDT_All
            var infos = new CorsairDeviceInfo[64];
            int count;
            err = CorsairGetDevices(ref filter, infos.Length, infos, out count);
            if (err != 0) throw new Exception("CorsairGetDevices failed with error code " + err + ".");

            var names = new List<string>();
            for (int i = 0; i < count && i < infos.Length; i++)
            {
                var positions = new CorsairLedPosition[512];
                int ledCount;
                if (CorsairGetLedPositions(infos[i].id, positions.Length, positions, out ledCount) != 0 || ledCount <= 0) continue;
                ledCount = Math.Min(ledCount, positions.Length);

                double minX = double.MaxValue, maxX = double.MinValue, minY = double.MaxValue, maxY = double.MinValue;
                for (int j = 0; j < ledCount; j++)
                {
                    minX = Math.Min(minX, positions[j].cx); maxX = Math.Max(maxX, positions[j].cx);
                    minY = Math.Min(minY, positions[j].cy); maxY = Math.Max(maxY, positions[j].cy);
                }
                var d = new DeviceLeds
                {
                    Id = infos[i].id, Colors = new CorsairLedColor[ledCount],
                    X = new double[ledCount], Y = new double[ledCount], LastSent = new uint[ledCount]
                };
                for (int j = 0; j < ledCount; j++)
                {
                    d.Colors[j].id = positions[j].id;
                    d.X[j] = maxX > minX ? (positions[j].cx - minX) / (maxX - minX) : 0.5;
                    d.Y[j] = maxY > minY ? (positions[j].cy - minY) / (maxY - minY) : 0.5;
                    d.LastSent[j] = 0xFFFFFFFF;   // force the first send
                }
                _devices.Add(d);
                names.Add(infos[i].model + " (" + ledCount + " LEDs)");
            }

            if (_devices.Count == 0)
                throw new Exception("Connected to iCUE, but no controllable devices were found. Check that your devices are enabled for the SDK in iCUE settings.");

            lock (_lock)
            {
                SendFrame(true);                 // transparent: normal iCUE lighting shows
                CorsairSetLayerPriority(0);      // sit below iCUE's own layer (127) while idle
            }
            return string.Join(", ", names.ToArray());
        }

        // ---------------------------------------------------------------------------------------
        // Effect triggers (any thread)
        // ---------------------------------------------------------------------------------------

        // secondsSincePlant: how long ago the bomb was actually planted (0 if we saw it happen).
        public static void StartFlash(double secondsSincePlant)
        {
            lock (_lock)
            {
                if (!_connected || _flashing) return;
                _flashing = true;
                _lit = false;
                _nextBeep = 0;                   // first blink right away, then follow the beep schedule
                _litUntil = 0;
                _startOffset = secondsSincePlant;
                _clock.Restart();
                Wake();
            }
        }

        public static void StopFlash()
        {
            lock (_lock) { if (_flashing) { _flashing = false; _lit = false; _clock.Stop(); Wake(); } }
        }

        // damage: health lost in this hit (1-100).
        public static void Hit(double damage)
        {
            lock (_lock) { _hitAt = Now; _hitStrength = Math.Min(1.0, 0.35 + damage / 70.0); Wake(); }
        }

        public static void SetDead(bool dead)
        {
            lock (_lock)
            {
                if (dead == _dead) return;
                _dead = dead;
                if (dead) _deathAt = Now;
                Wake();
            }
        }

        public static void SetFlashed(int value0to255)
        {
            lock (_lock) { double v = Clamp(value0to255 / 255.0); if (v != _flashed) { _flashed = v; Wake(); } }
        }

        public static void SetSmoked(int value0to255)
        {
            lock (_lock) { double v = Clamp(value0to255 / 255.0); if (v != _smoked) { _smoked = v; Wake(); } }
        }
        public static void Headshot() { lock (_lock) { _headshotAt = Now; Wake(); } }
        public static void Kill() { lock (_lock) { _killAt = Now; Wake(); } }

        // damage: damage you just dealt to an enemy.
        public static void HitMarker(double damage)
        {
            lock (_lock) { _markerAt = Now; _markerStrength = Math.Min(0.85, 0.4 + damage / 150.0); Wake(); }
        }
        public static void Defused() { lock (_lock) { _defuseAt = Now; Wake(); } }

        // team: "CT" or "T"
        public static void RoundWon(string team)
        {
            lock (_lock)
            {
                _winColor = team == "CT" ? new Rgba(40, 120, 255, 1) : new Rgba(255, 140, 0, 1);
                _winAt = Now;
                Wake();
            }
        }

        // Clears everything that depends on the player's live state (menus, map change, etc.)
        public static void ClearPlayerState()
        {
            lock (_lock) { _flashed = 0; _smoked = 0; _dead = false; Wake(); }
        }

        // ---------------------------------------------------------------------------------------
        // Renderer: one timer thread draws every effect into a frame and sends only what changed.
        // ---------------------------------------------------------------------------------------

        static double Now { get { return _now.Elapsed.TotalSeconds; } }
        static double Clamp(double v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

        static void Wake()
        {
            if (!_connected || _running) return;
            _running = true;
            FineTimer(true);
            if (_timer == null) _timer = new Timer(Tick, null, 0, 5);
            else _timer.Change(0, 5);
        }

        static bool AnythingActive(double now)
        {
            return _flashing || _dead || _flashed > 0 || _smoked > 0 ||
                   now - _hitAt < HitSeconds || now - _headshotAt < HeadshotSeconds ||
                   now - _winAt < WinSeconds || now - _defuseAt < DefuseSeconds ||
                   now - _markerAt < MarkerSeconds || now - _killAt < KillSeconds;
        }

        static void Tick(object state)
        {
            if (!Monitor.TryEnter(_lock)) return;   // skip a tick rather than pile up
            try
            {
                if (!_running) return;
                double now = Now;
                bool bombEdge = UpdateBomb();
                bool active = AnythingActive(now);

                if (active && !_layerOnTop) { CorsairSetLayerPriority(255); _layerOnTop = true; }   // jump on top of everything

                // Bomb blinks go out the moment they're due; fades are capped at ~60 frames a second.
                if (bombEdge || !active || now - _lastSend >= 0.016)
                {
                    SendFrame(false);
                    _lastSend = now;
                }

                if (!active)
                {
                    if (_layerOnTop) { CorsairSetLayerPriority(0); _layerOnTop = false; }
                    _running = false;
                    if (_timer != null) _timer.Change(Timeout.Infinite, Timeout.Infinite);
                    FineTimer(false);
                }
            }
            catch (Exception) { }
            finally { Monitor.Exit(_lock); }
        }

        // Advances the beep schedule. Returns true when the bomb light switched on or off.
        static bool UpdateBomb()
        {
            if (!_flashing) return false;
            double t = _clock.Elapsed.TotalSeconds + _startOffset;
            if (t > BombTimer + 5) { _flashing = false; _lit = false; return true; }   // safety stop if CS2 goes quiet

            if (t >= _nextBeep)
            {
                // Beep: light up. The schedule is computed from the planned beep times, not from
                // when this tick happened to run, so timer jitter never adds up into drift.
                double beepAt = _nextBeep;
                double pulse = PulseLength(BeepInterval(beepAt));
                _nextBeep = beepAt + BeepInterval(beepAt);
                while (_nextBeep <= t) _nextBeep += BeepInterval(_nextBeep);   // PC stalled: skip missed beeps

                // Normally the blink ends `pulse` after its beep. If this beep is being shown late
                // (the very first one always is, because CS2 reports the plant a moment after it
                // happens), still give it a full-length blink, ending before the next beep.
                _litUntil = Math.Max(beepAt + pulse, Math.Min(t + pulse, _nextBeep - 0.03));
                _lit = true;
                return true;
            }
            if (_lit && t >= _litUntil) { _lit = false; return true; }
            return false;
        }

        // Layers, bottom to top: death, smoke, round won, defuse, bomb, hit marker, kill, hit, headshot, flashbang.
        static Rgba Pixel(double now, double x, double y)
        {
            var c = new Rgba(0, 0, 0, 0);

            if (_dead)
            {
                double age = now - _deathAt;
                Over(ref c, new Rgba(35, 35, 40, 0.88 * Clamp(age / 0.35)));          // fade to grey
                if (age < 0.35) Over(ref c, new Rgba(255, 0, 0, 1 - age / 0.35));     // red jolt first
            }

            if (_smoked > 0) Over(ref c, new Rgba(110, 110, 118, 0.85 * _smoked));

            double win = now - _winAt;
            if (win < WinSeconds)
            {
                // Team-color wipe left to right, hold, then fade.
                double front = win / 0.5;
                double edge = Clamp((front - x) / 0.15 + 1);
                double fade = win < 1.0 ? 1 : 1 - (win - 1.0) / (WinSeconds - 1.0);
                Over(ref c, new Rgba(_winColor.R, _winColor.G, _winColor.B, edge * Clamp(fade)));
            }

            double def = now - _defuseAt;
            if (def < DefuseSeconds)
            {
                // Green ring spreading from the middle over a fading green glow.
                Over(ref c, new Rgba(0, 255, 90, 0.7 * (1 - def / DefuseSeconds)));
                Over(ref c, new Rgba(120, 255, 160, Ring(x, y, def / 0.7, 0.2) * (1 - def / DefuseSeconds)));
            }

            if (_flashing) Over(ref c, _lit ? new Rgba(R, G, B, 1) : new Rgba(0, 0, 0, 1));

            double mk = now - _markerAt;
            if (mk < MarkerSeconds)
            {
                // Hit marker: a short icy-white tick when you damage someone.
                Over(ref c, new Rgba(190, 235, 255, _markerStrength * (1 - mk / MarkerSeconds)));
            }

            double kill = now - _killAt;
            if (kill < KillSeconds)
            {
                // Kill (not a headshot): a white pop, then a white ring spreading from the middle.
                double k = 1 - kill / KillSeconds;
                if (kill < 0.08) Over(ref c, new Rgba(255, 255, 255, 0.5 * (1 - kill / 0.08)));
                Over(ref c, new Rgba(235, 240, 255, Ring(x, y, kill / 0.42, 0.18) * k));
            }

            double hit = now - _hitAt;
            if (hit < HitSeconds)
            {
                double k = 1 - hit / HitSeconds;
                Over(ref c, new Rgba(255, 10, 10, _hitStrength * k * k));
            }

            double hs = now - _headshotAt;
            if (hs < HeadshotSeconds)
            {
                // Quick gold pop, then a gold ring spreading out from the middle.
                double k = 1 - hs / HeadshotSeconds;
                if (hs < 0.1) Over(ref c, new Rgba(255, 190, 0, 0.6 * (1 - hs / 0.1)));
                Over(ref c, new Rgba(255, 200, 40, Ring(x, y, hs / 0.45, 0.18) * k));
            }

            if (_flashed > 0) Over(ref c, new Rgba(255, 255, 255, _flashed));

            return c;
        }

        // 1 on a ring of the given radius around the middle of the device, fading out to 0.
        static double Ring(double x, double y, double radius, double width)
        {
            double d = Math.Sqrt((x - 0.5) * (x - 0.5) + (y - 0.5) * (y - 0.5)) / 0.7071;   // 0 middle, 1 corner
            return Clamp(1 - Math.Abs(d - radius) / width);
        }

        // Standard "over" alpha compositing of src onto dst.
        static void Over(ref Rgba dst, Rgba src)
        {
            double a = Clamp(src.A);
            if (a <= 0) return;
            double outA = a + dst.A * (1 - a);
            if (outA <= 0) { dst = new Rgba(0, 0, 0, 0); return; }
            dst.R = (src.R * a + dst.R * dst.A * (1 - a)) / outA;
            dst.G = (src.G * a + dst.G * dst.A * (1 - a)) / outA;
            dst.B = (src.B * a + dst.B * dst.A * (1 - a)) / outA;
            dst.A = outA;
        }

        static byte B8(double v) { return (byte)Math.Max(0, Math.Min(255, Math.Round(v))); }

        static void SendFrame(bool force)
        {
            double now = Now;
            foreach (DeviceLeds d in _devices)
            {
                bool changed = force;
                for (int i = 0; i < d.Colors.Length; i++)
                {
                    Rgba p = Pixel(now, d.X[i], d.Y[i]);
                    byte a = B8(p.A * 255);
                    byte r = a == 0 ? (byte)0 : B8(p.R), g = a == 0 ? (byte)0 : B8(p.G), b = a == 0 ? (byte)0 : B8(p.B);
                    d.Colors[i].r = r; d.Colors[i].g = g; d.Colors[i].b = b; d.Colors[i].a = a;
                    uint packed = ((uint)r << 24) | ((uint)g << 16) | ((uint)b << 8) | a;
                    if (packed != d.LastSent[i]) { d.LastSent[i] = packed; changed = true; }
                }
                if (changed) CorsairSetLedColors(d.Id, d.Colors.Length, d.Colors);
            }
        }

        // Ask Windows for 1 ms timer resolution while effects run so bomb blinks land within a
        // millisecond or two of each beep (the default is about 16 ms).
        static void FineTimer(bool on)
        {
            if (on == _fineTimer) return;
            try
            {
                if (on) timeBeginPeriod(1); else timeEndPeriod(1);
                _fineTimer = on;
            }
            catch (Exception) { }
        }

        public static void Shutdown()
        {
            lock (_lock)
            {
                if (_timer != null) { _timer.Dispose(); _timer = null; }
                _running = false;
                _flashing = false; _dead = false; _flashed = 0; _smoked = 0;
                _hitAt = _headshotAt = _winAt = _defuseAt = _markerAt = _killAt = -99;
                FineTimer(false);
                if (!_connected) return;
                if (_devices.Count > 0) { SendFrame(true); CorsairSetLayerPriority(0); }
                CorsairDisconnect();
                _connected = false;
            }
        }
    }


    // -----------------------------------------------------------------------------------------
    // Finds iCUESDK.x64_2019.dll: next to the exe, embedded in the exe, already extracted, or
    // inside an iCUESDK_*.zip next to the exe or in the Downloads folder.
    // -----------------------------------------------------------------------------------------
    static class SdkLocator
    {
        static readonly Guid DownloadsFolderId = new Guid("374DE290-123F-4565-9164-39C4925E467B");

        [DllImport("shell32.dll")]
        static extern int SHGetKnownFolderPath([MarshalAs(UnmanagedType.LPStruct)] Guid rfid, uint flags, IntPtr token, out IntPtr path);

        public static string Find(out string source)
        {
            string exeDir = AppDomain.CurrentDomain.BaseDirectory;
            string cacheDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CS2BombLights");
            string cached = Path.Combine(cacheDir, Icue.DllName);

            string beside = Path.Combine(exeDir, Icue.DllName);
            if (File.Exists(beside)) { source = beside; return beside; }

            using (Stream embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream(Icue.DllName))
            {
                if (embedded != null)
                {
                    try
                    {
                        Directory.CreateDirectory(cacheDir);
                        if (!File.Exists(cached) || new FileInfo(cached).Length != embedded.Length)
                        {
                            using (var f = File.Create(cached)) embedded.CopyTo(f);
                        }
                        source = "built in (" + cached + ")";
                        return cached;
                    }
                    catch (IOException) { if (File.Exists(cached)) { source = cached; return cached; } }
                    catch (UnauthorizedAccessException) { }
                }
            }

            var zips = new List<FileInfo>();
            foreach (string dir in new[] { exeDir, DownloadsFolder() })
            {
                if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) continue;
                try { zips.AddRange(new DirectoryInfo(dir).GetFiles("iCUESDK*.zip")); } catch { }
            }
            zips.Sort((a, b) => b.LastWriteTimeUtc.CompareTo(a.LastWriteTimeUtc));   // newest first

            foreach (FileInfo zip in zips)
            {
                try
                {
                    byte[] dll = MiniZip.Extract(File.ReadAllBytes(zip.FullName), path =>
                    {
                        string p = path.Replace('\\', '/');
                        return p.EndsWith("/" + Icue.DllName, StringComparison.OrdinalIgnoreCase) &&
                               p.IndexOf("x64/", StringComparison.OrdinalIgnoreCase) >= 0;
                    });
                    if (dll == null) continue;

                    Directory.CreateDirectory(cacheDir);
                    string tmp = cached + ".tmp";
                    File.WriteAllBytes(tmp, dll);
                    if (File.Exists(cached)) File.Delete(cached);
                    File.Move(tmp, cached);
                    source = "extracted from " + zip.FullName;
                    return cached;
                }
                catch (Exception) { }
            }

            if (File.Exists(cached)) { source = cached; return cached; }

            source = null;
            return null;
        }

        static string DownloadsFolder()
        {
            try
            {
                IntPtr p;
                if (SHGetKnownFolderPath(DownloadsFolderId, 0, IntPtr.Zero, out p) == 0)
                {
                    try { return Marshal.PtrToStringUni(p); }
                    finally { Marshal.FreeCoTaskMem(p); }
                }
            }
            catch { }
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        }
    }

    // -----------------------------------------------------------------------------------------
    // Reads one file out of a .zip (stored or deflated, CRC-checked). Uses DeflateStream from
    // System.dll so the exe has no dependencies beyond the base .NET Framework.
    // -----------------------------------------------------------------------------------------
    static class MiniZip
    {
        public static byte[] Extract(byte[] zip, Predicate<string> match)
        {
            int eocd = -1;
            for (int i = zip.Length - 22; i >= 0 && i >= zip.Length - 22 - 65535; i--)
                if (U32(zip, i) == 0x06054b50) { eocd = i; break; }
            if (eocd < 0) throw new InvalidDataException("Not a zip file.");

            int entries = U16(zip, eocd + 10);
            int p = (int)U32(zip, eocd + 16);
            for (int e = 0; e < entries; e++)
            {
                if (U32(zip, p) != 0x02014b50) throw new InvalidDataException("Bad zip central directory.");
                int method = U16(zip, p + 10);
                uint crc = U32(zip, p + 16);
                int compSize = (int)U32(zip, p + 20);
                int size = (int)U32(zip, p + 24);
                int nameLen = U16(zip, p + 28), extraLen = U16(zip, p + 30), commentLen = U16(zip, p + 32);
                int local = (int)U32(zip, p + 42);
                string name = Encoding.UTF8.GetString(zip, p + 46, nameLen);
                p += 46 + nameLen + extraLen + commentLen;

                if (!match(name)) continue;
                if (U32(zip, local) != 0x04034b50) throw new InvalidDataException("Bad zip local header.");
                int dataStart = local + 30 + U16(zip, local + 26) + U16(zip, local + 28);

                byte[] output = new byte[size];
                if (method == 0)
                {
                    Buffer.BlockCopy(zip, dataStart, output, 0, size);
                }
                else if (method == 8)
                {
                    using (var ds = new DeflateStream(new MemoryStream(zip, dataStart, compSize), CompressionMode.Decompress))
                    {
                        int got = 0;
                        while (got < size)
                        {
                            int n = ds.Read(output, got, size - got);
                            if (n <= 0) throw new InvalidDataException("Zip entry is truncated.");
                            got += n;
                        }
                    }
                }
                else throw new InvalidDataException("Unsupported zip compression method " + method + ".");

                if (Crc32(output) != crc) throw new InvalidDataException("Zip entry failed its CRC check.");
                return output;
            }
            return null;
        }

        static int U16(byte[] b, int i) { return b[i] | (b[i + 1] << 8); }
        static uint U32(byte[] b, int i) { return (uint)(b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)); }

        static uint Crc32(byte[] data)
        {
            uint crc = 0xFFFFFFFF;
            foreach (byte x in data)
            {
                crc ^= x;
                for (int k = 0; k < 8; k++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xEDB88320 : crc >> 1;
            }
            return ~crc;
        }
    }

    // -----------------------------------------------------------------------------------------
    // Finds CS2 through Steam and writes the Game State Integration config.
    // -----------------------------------------------------------------------------------------
    enum ConfigResult { Unchanged, Written, Failed }

    static class SteamSetup
    {
        public const string ConfigFileName = "gamestate_integration_icue_bomb.cfg";

        public static string ConfigText(int port)
        {
            return string.Join("\r\n", new[]
            {
                "\"iCUE Bomb Flash\"",
                "{",
                "    \"uri\"       \"http://127.0.0.1:" + port.ToString(CultureInfo.InvariantCulture) + "\"",
                "    \"timeout\"   \"5.0\"",
                "    \"buffer\"    \"0.0\"",
                "    \"throttle\"  \"0.0\"",   // send every change right away (default would wait up to 1 s)
                "    \"heartbeat\" \"10.0\"",
                "    \"auth\"",
                "    {",
                "        \"token\" \"" + Program.AuthToken + "\"",
                "    }",
                "    \"data\"",
                "    {",
                "        \"provider\"       \"1\"",
                "        \"round\"          \"1\"",
                "        \"player_id\"      \"1\"",
                "        \"player_weapons\" \"1\"",
                "        \"player_state\"   \"1\"",
                "    }",
                "}",
                ""
            });
        }

        public static ConfigResult InstallConfig(int port, out string message)
        {
            string text = ConfigText(port);
            string cfgDir = FindCs2CfgDir();
            if (cfgDir == null)
            {
                string fallback = SaveBesideExe(text);
                message = "Couldn't find CS2 in your Steam libraries. Copy " + (fallback ?? ConfigFileName) +
                          " into ...\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg yourself.";
                return ConfigResult.Failed;
            }

            string target = Path.Combine(cfgDir, ConfigFileName);
            try
            {
                if (File.Exists(target) && File.ReadAllText(target) == text)
                {
                    message = target;
                    return ConfigResult.Unchanged;
                }
                Directory.CreateDirectory(cfgDir);
                File.WriteAllText(target, text, new UTF8Encoding(false));
                message = target;
                return ConfigResult.Written;
            }
            catch (Exception ex)
            {
                string fallback = SaveBesideExe(text);
                message = "Couldn't write " + target + " (" + ex.Message + "). Copy " + (fallback ?? ConfigFileName) + " there yourself.";
                return ConfigResult.Failed;
            }
        }

        static string SaveBesideExe(string text)
        {
            try
            {
                string p = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ConfigFileName);
                File.WriteAllText(p, text, new UTF8Encoding(false));
                return p;
            }
            catch { return null; }
        }

        public static string FindCs2CfgDir()
        {
            foreach (string lib in SteamLibraries())
            {
                string game = Path.Combine(Path.Combine(Path.Combine(lib, "steamapps"), "common"), "Counter-Strike Global Offensive");
                string csgo = Path.Combine(Path.Combine(game, "game"), "csgo");
                if (Directory.Exists(csgo)) return Path.Combine(csgo, "cfg");
            }
            return null;
        }

        static List<string> SteamLibraries()
        {
            var libs = new List<string>();
            string steam = SteamPath();
            if (steam == null) return libs;
            libs.Add(steam);

            string vdf = Path.Combine(Path.Combine(steam, "steamapps"), "libraryfolders.vdf");
            try
            {
                if (File.Exists(vdf))
                {
                    foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s*\"((?:[^\"\\\\]|\\\\.)*)\""))
                    {
                        string p = m.Groups[1].Value.Replace("\\\\", "\\").Replace("\\\"", "\"");
                        if (!libs.Exists(x => string.Equals(Norm(x), Norm(p), StringComparison.OrdinalIgnoreCase))) libs.Add(p);
                    }
                }
            }
            catch { }
            return libs;
        }

        static string Norm(string p)
        {
            try { return Path.GetFullPath(p).TrimEnd('\\', '/'); } catch { return p; }
        }

        static string SteamPath()
        {
            string[][] keys =
            {
                new[] { "HKCU", @"Software\Valve\Steam", "SteamPath" },
                new[] { "HKLM", @"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath" },
                new[] { "HKLM", @"SOFTWARE\Valve\Steam", "InstallPath" },
            };
            foreach (string[] k in keys)
            {
                try
                {
                    RegistryKey root = k[0] == "HKCU" ? Registry.CurrentUser : Registry.LocalMachine;
                    using (RegistryKey key = root.OpenSubKey(k[1]))
                    {
                        string v = key == null ? null : key.GetValue(k[2]) as string;
                        if (!string.IsNullOrEmpty(v))
                        {
                            v = v.Replace('/', Path.DirectorySeparatorChar);
                            if (Directory.Exists(v)) return v;
                        }
                    }
                }
                catch { }
            }
            string def = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam");
            return Directory.Exists(def) ? def : null;
        }
    }

    // -----------------------------------------------------------------------------------------
    // CS2 process helpers
    // -----------------------------------------------------------------------------------------
    static class Game
    {
        public static bool IsRunning()
        {
            Process[] ps = Process.GetProcessesByName("cs2");
            foreach (Process p in ps) p.Dispose();
            return ps.Length > 0;
        }

        public static void Launch()
        {
            try
            {
                Process.Start(new ProcessStartInfo("steam://rungameid/730") { UseShellExecute = true });
                Log.Write("Starting CS2 through Steam...", ConsoleColor.Gray);
            }
            catch (Exception ex)
            {
                Log.Write("Couldn't start CS2 through Steam (" + ex.Message + "). Start it yourself; I'll wait.", ConsoleColor.Yellow);
            }
        }
    }

    // -----------------------------------------------------------------------------------------
    // Tiny JSON reader: objects -> Dictionary<string, object>, arrays -> List<object>,
    // strings, doubles, bools, null.
    // -----------------------------------------------------------------------------------------
    static class Json
    {
        public static object Parse(string s)
        {
            int i = 0;
            object v = Value(s, ref i, 0);
            Ws(s, ref i);
            if (i != s.Length) throw new FormatException("Unexpected data after JSON value.");
            return v;
        }

        public static Dictionary<string, object> Obj(Dictionary<string, object> d, string key)
        {
            object v;
            return d != null && d.TryGetValue(key, out v) ? v as Dictionary<string, object> : null;
        }

        public static double Num(Dictionary<string, object> d, string key, double fallback)
        {
            object v;
            return d != null && d.TryGetValue(key, out v) && v is double ? (double)v : fallback;
        }

        public static string Str(Dictionary<string, object> d, string key)
        {
            object v;
            return d != null && d.TryGetValue(key, out v) ? v as string : null;
        }

        static object Value(string s, ref int i, int depth)
        {
            if (depth > 64) throw new FormatException("JSON nested too deeply.");
            Ws(s, ref i);
            if (i >= s.Length) throw new FormatException("Unexpected end of JSON.");
            char c = s[i];
            if (c == '{')
            {
                i++;
                var d = new Dictionary<string, object>(StringComparer.Ordinal);
                Ws(s, ref i);
                if (Peek(s, i) == '}') { i++; return d; }
                while (true)
                {
                    Ws(s, ref i);
                    string k = String(s, ref i);
                    Ws(s, ref i);
                    Expect(s, ref i, ':');
                    d[k] = Value(s, ref i, depth + 1);
                    Ws(s, ref i);
                    char n = Peek(s, i);
                    if (n == ',') { i++; continue; }
                    if (n == '}') { i++; return d; }
                    throw new FormatException("Expected ',' or '}' in JSON object.");
                }
            }
            if (c == '[')
            {
                i++;
                var list = new List<object>();
                Ws(s, ref i);
                if (Peek(s, i) == ']') { i++; return list; }
                while (true)
                {
                    list.Add(Value(s, ref i, depth + 1));
                    Ws(s, ref i);
                    char n = Peek(s, i);
                    if (n == ',') { i++; continue; }
                    if (n == ']') { i++; return list; }
                    throw new FormatException("Expected ',' or ']' in JSON array.");
                }
            }
            if (c == '"') return String(s, ref i);
            if (Literal(s, ref i, "true")) return true;
            if (Literal(s, ref i, "false")) return false;
            if (Literal(s, ref i, "null")) return null;

            int start = i;
            while (i < s.Length && "+-0123456789.eE".IndexOf(s[i]) >= 0) i++;
            if (i == start) throw new FormatException("Unexpected character '" + c + "' in JSON.");
            return double.Parse(s.Substring(start, i - start), NumberStyles.Float, CultureInfo.InvariantCulture);
        }

        static string String(string s, ref int i)
        {
            Expect(s, ref i, '"');
            var sb = new StringBuilder();
            while (true)
            {
                if (i >= s.Length) throw new FormatException("Unterminated JSON string.");
                char c = s[i++];
                if (c == '"') return sb.ToString();
                if (c != '\\') { sb.Append(c); continue; }
                if (i >= s.Length) throw new FormatException("Unterminated JSON escape.");
                char e = s[i++];
                switch (e)
                {
                    case '"': sb.Append('"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'u':
                        if (i + 4 > s.Length) throw new FormatException("Bad \\u escape in JSON.");
                        sb.Append((char)int.Parse(s.Substring(i, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture));
                        i += 4;
                        break;
                    default: throw new FormatException("Bad escape in JSON string.");
                }
            }
        }

        static bool Literal(string s, ref int i, string word)
        {
            if (string.CompareOrdinal(s, i, word, 0, word.Length) != 0) return false;
            i += word.Length;
            return true;
        }

        static void Expect(string s, ref int i, char c)
        {
            if (Peek(s, i) != c) throw new FormatException("Expected '" + c + "' in JSON.");
            i++;
        }

        static char Peek(string s, int i) { return i < s.Length ? s[i] : '\0'; }

        static void Ws(string s, ref int i)
        {
            while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++;
        }
    }
}
